Auctions Service

Swagger UI available at:
http://localhost:8080/swagger-ui/index.html#/

Actors:
- Seller
- Buyer
- Admin

Use cases for Seller

1. Add Auction
2. Edit Auction
3. End Auction

Use cases for Buyer

1. Buy
2. Add Review
3. Search