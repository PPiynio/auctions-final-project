package com.sda.auctionsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
