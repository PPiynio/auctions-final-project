package com.sda.auctionsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctionsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuctionsServiceApplication.class, args);
	}

}
